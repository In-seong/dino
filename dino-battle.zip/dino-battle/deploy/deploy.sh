#!/usr/bin/env bash
# DinoFace Battle 배포 스크립트 (서버에서 root로 실행)
# 사용법: bash deploy.sh
# - /var/www/dino.revuplan.com 에만 파일을 쓰고
# - nginx에는 dino.revuplan.com 전용 server block 하나만 추가합니다 (기존 사이트 무영향)
set -euo pipefail
cd "$(dirname "$0")/.."

DOMAIN=dino.revuplan.com
WEBROOT=/var/www/$DOMAIN

echo "[1/4] 파일 복사 → $WEBROOT"
mkdir -p "$WEBROOT"
cp -f index.html three.min.js "$WEBROOT/"
chown -R www-data:www-data "$WEBROOT" 2>/dev/null || true

echo "[2/4] nginx 설정 추가"
if [ -d /etc/nginx/sites-available ]; then
  cp -f deploy/$DOMAIN.conf /etc/nginx/sites-available/$DOMAIN
  ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/$DOMAIN
else
  cp -f deploy/$DOMAIN.conf /etc/nginx/conf.d/$DOMAIN.conf
fi

echo "[3/4] nginx 문법 검사 후 reload (reload는 기존 서비스를 끊지 않음)"
nginx -t
systemctl reload nginx

echo "[4/4] HTTPS 인증서 (카메라 기능에 필수)"
if command -v certbot >/dev/null; then
  certbot --nginx -d $DOMAIN --non-interactive --agree-tos --register-unsafely-without-email --redirect || \
    echo "  !! certbot 실패: 'certbot --nginx -d $DOMAIN' 를 수동 실행하세요"
else
  echo "  !! certbot 미설치: apt install certbot python3-certbot-nginx 후 'certbot --nginx -d $DOMAIN' 실행"
fi

echo "완료 → https://$DOMAIN"
